import { Routes, Route } from "react-router-dom";
import DashboardLayout from "./components/DashboardLayout";
import LiveSession from "./pages/LiveSession";
import AdminPanel from "./pages/AdminPanel";
import Profile from "./pages/Profile";
import DashboardHome from "./pages/DashboardHome";
import AdminDashboard from "./pages/AdminDashboard";
import Rewards from "./pages/Rewards";
import AdminRewards from "./pages/AdminRewards"; // ✅ NEW
import Tasks from "./pages/Tasks";

function App() {
  return (
    <Routes>
      <Route path="/" element={<DashboardLayout />}>
        <Route index element={<DashboardHome />} />
        <Route path="live" element={<LiveSession />} />
        <Route path="profile" element={<Profile />} />
        <Route path="rewards" element={<Rewards />} />
        <Route path="admin/dashboard" element={<AdminDashboard />} />
        <Route path="admin/rewards" element={<AdminRewards />} /> {/* ✅ NEW */}
        <Route path="/admin/tasks" element={<Tasks />} />
      </Route>

      <Route path="/admin" element={<AdminPanel />} />
    </Routes>
  );
}

export default App;
