import { useEffect, useState } from "react";
import axios from "axios";
import "./Rewards.css"; // Optional: for basic styling

export default function Rewards() {
  const [rewards, setRewards] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    axios.get("http://localhost:5000/api/shop")
      .then((res) => {
        setRewards(res.data);
        setLoading(false);
      })
      .catch((err) => {
        console.error("Error fetching rewards:", err);
        setLoading(false);
      });
  }, []);

  const handleRedeem = (rewardId) => {
    axios.post("http://localhost:5000/api/shop/redeem", {
      userId: "demo-user",  // Replace with actual logged-in user ID
      rewardId
    })
    .then(() => alert("Reward redeemed!"))
    .catch(() => alert("Redeem failed."));
  };

  return (
    <div className="rewards-container">
      <h2>🏆 Redeem Your Rewards</h2>
      {loading ? (
        <p>Loading rewards...</p>
      ) : (
        <div className="reward-list">
          {rewards.map((reward) => (
            <div className="reward-card" key={reward.id}>
              <h3>{reward.title}</h3>
              <p>Cost: {reward.cost} coins</p>
              <button onClick={() => handleRedeem(reward.id)}>Redeem</button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
