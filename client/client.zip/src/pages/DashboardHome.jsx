import React from "react";
import styles from "../styles/DashboardHome.module.css";

export default function DashboardHome() {
  return (
    <div className={styles.container}>
      <h2 className={styles.greeting}>Hello, Abhi!</h2>

      <div className={styles.stats}>
        <div className={styles.statCard}>
          <span>💰</span>
          <p><strong>120</strong><br />Coins</p>
        </div>
        <div className={styles.statCard}>
          <span>✅</span>
          <p><strong>3</strong><br />Completed</p>
        </div>
        <div className={styles.statCard}>
          <span>📄</span>
          <p><strong>2</strong><br />Certificates</p>
        </div>
      </div>

      <div className={styles.card}>
        <h3>Continue Learning</h3>
        <p className={styles.course}>How to Prepare for Interviews</p>
        <button className={styles.resume}>Resume</button>
      </div>

      <div className={styles.card}>
        <h3>Upcoming Live Session</h3>
        <p>📅 With Mr. X</p>
        <p>🕒 May 25, 2024 at 3:00 PM</p>
      </div>

      <h3 className={styles.subheading}>Recommended for You</h3>
      <div className={styles.grid}>
        <div className={styles.tile}>Effective Communic.</div>
        <div className={styles.tile}>Data Analysis Fundamentals</div>
      </div>

      <h3 className={styles.subheading}>Recommended for You</h3>
      <div className={styles.grid}>
        <div className={styles.tile}>Effective Communic.</div>
        <div className={styles.tile}>Project Management Essentials</div>
      </div>
    </div>
  );
}
