import { useState } from "react";
import axios from "axios";
import './AdminPanel.css';


export default function AdminPanel() {
  const [title, setTitle] = useState("");
  const [videoUrl, setVideoUrl] = useState("");

  const handleStartSession = async (e) => {
    e.preventDefault();
    try {
      await axios.post("http://localhost:5000/api/sessions/start", {
        title,
        videoUrl,
      });
      alert("Live session started!");
      setTitle("");
      setVideoUrl("");
    } catch (err) {
      console.error(err);
      alert("Failed to start session.");
    }
  };

  return (

      <div className="admin-container">
        <h1 className="admin-heading">Admin Panel</h1>
        

        <h2 className="admin-heading">Start a Live Session</h2>
        <form onSubmit={handleStartSession} className="admin-form">
          <div>
            <label>Session Title:</label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              required
            />
          </div>
          <div>
            <label>YouTube Embed URL:</label>
            <input
              type="text"
              value={videoUrl}
              onChange={(e) => setVideoUrl(e.target.value)}
              required
              placeholder="e.g. https://www.youtube.com/embed/live_stream_id"
            />
          </div>
          <button type="submit">Start Session</button>
        </form>
      </div>

  );
}
