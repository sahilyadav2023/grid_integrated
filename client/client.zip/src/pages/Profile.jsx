// src/pages/Profile.jsx
import React, { useState } from "react";
import styles from "../styles/Profile.module.css";

export default function Profile() {
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState("Abhi");
  const [email] = useState("abhi@example.com");
  const [tagline, setTagline] = useState("Frontend Learner");
  const [avatar, setAvatar] = useState(null);

  const handleAvatarChange = (e) => {
    const file = e.target.files[0];
    if (file) setAvatar(URL.createObjectURL(file));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setEditing(false);
  };

  return (
    <div className={styles.container}>
      <div className={styles.headerSection}>
        <img
          className={styles.avatar}
          src={avatar || "/avatar-placeholder.png"}
          alt="Avatar"
        />
        <div>
          <h1>{name}</h1>
          <p className={styles.email}>{email}</p>
          <p className={styles.tagline}>{tagline}</p>
        </div>
        <button className={styles.editButton} onClick={() => setEditing(!editing)}>
          {editing ? "Cancel" : "Edit Profile"}
        </button>
      </div>

      <div className={styles.statsGrid}>
        <div className={styles.statCard}>
          <p className={styles.statValue}>3</p>
          <p>Enrolled Courses</p>
        </div>
        <div className={styles.statCard}>
          <p className={styles.statValue}>1</p>
          <p>Certificate Earned</p>
        </div>
        <div className={styles.statCard}>
          <p className={styles.statValue}>120</p>
          <p>Coins Earned</p>
        </div>
      </div>

      {editing && (
        <form className={styles.editForm} onSubmit={handleSubmit}>
          <div>
            <label>Full Name</label>
            <input value={name} onChange={(e) => setName(e.target.value)} />
          </div>
          <div>
            <label>Email Address</label>
            <input value={email} readOnly />
          </div>
          <div>
            <label>Tagline</label>
            <input value={tagline} onChange={(e) => setTagline(e.target.value)} />
          </div>
          <div>
            <label>Upload Avatar</label>
            <input type="file" onChange={handleAvatarChange} />
          </div>
          <button type="submit" className={styles.saveButton}>
            Save Changes
          </button>
        </form>
      )}
    </div>
  );
}
