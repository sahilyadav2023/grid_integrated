import React, { useEffect, useState } from "react";
import axios from "axios";
import { io } from "socket.io-client";
import styles from "../styles/LiveSession.module.css";

const socket = io("http://localhost:5000"); // Replace with your backend host

export default function LiveSession() {
  const [session, setSession] = useState(null);
  const [error, setError] = useState("");
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [username, setUsername] = useState("User" + Math.floor(Math.random() * 1000));

  useEffect(() => {
    // Fetch current live session
    const fetchLiveSession = async () => {
      try {
        const res = await axios.get("http://localhost:5000/api/sessions/live");
        setSession(res.data);
      } catch (err) {
        setError("No active session at the moment.");
      }
    };

    fetchLiveSession();

    // Socket.IO: Listen for incoming messages
    socket.on("chatMessage", (msg) => {
      setMessages((prev) => [...prev, msg]);
    });

    return () => {
      socket.off("chatMessage"); // Clean up
    };
  }, []);

  const getEmbedUrl = (url) => {
    if (!url) return "";
    if (url.includes("/embed/")) {
      return `${url}?autoplay=1&controls=0&modestbranding=1&rel=0`;
    }
    try {
      const videoId = new URL(url).searchParams.get("v");
      return `https://www.youtube.com/embed/${videoId}?autoplay=1&controls=0&modestbranding=1&rel=0`;
    } catch {
      return "";
    }
  };

  const handleSend = () => {
    if (input.trim()) {
      const msg = { user: username, text: input };
      socket.emit("chatMessage", msg); // Send to server
      setMessages((prev) => [...prev, msg]); // Local echo
      setInput("");
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === "Enter") handleSend();
  };

  return (
    <div className={styles.container}>
      {session ? (
        <>
          <div className={styles.videoSection}>
            <div className={styles.liveBadge}>LIVE</div>
            <h2 style={{ marginBottom: "1rem", fontSize: "1.5rem" }}>
              LIVE Q&A WITH{" "}
              <span style={{ color: "#7a341e", fontWeight: "bold" }}>
                {session.title}
              </span>
            </h2>

            <div className={styles.videoCard}>
              <iframe
                className={styles.iframe}
                src={getEmbedUrl(session.videoUrl)}
                title="Live Video"
                frameBorder="0"
                allow="autoplay; encrypted-media"
                allowFullScreen
              />
            </div>
          </div>

          <div className={styles.chatSection}>
            <h3 className={styles.chatTitle}>LIVE CHAT</h3>

            <div className={styles.chatMessages}>
              {messages.map((msg, index) => (
                <div className={styles.message} key={index}>
                  <div className={styles.avatar}></div>
                  <div>
                    <strong>{msg.user}</strong>
                    <p>{msg.text}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className={styles.inputArea}>
              <input
                type="text"
                className={styles.inputBox}
                placeholder="Enter your message..."
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
              />
              <button className={styles.sendBtn} onClick={handleSend}>
                ➤
              </button>
            </div>
          </div>
        </>
      ) : (
        <p style={{ margin: "auto", color: "#dc2626", fontSize: "1.25rem" }}>
          {error}
        </p>
      )}
    </div>
  );
}
