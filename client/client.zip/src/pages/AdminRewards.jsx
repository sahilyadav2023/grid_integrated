import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './AdminRewards.css';

export default function AdminRewards() {
  const [shopItems, setShopItems] = useState([]);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [cost, setCost] = useState('');

  const fetchItems = async () => {
    try {
      const res = await axios.get('http://localhost:5000/api/shop');
      setShopItems(res.data);
    } catch (err) {
      console.error('Failed to fetch shop items:', err);
    }
  };

  useEffect(() => {
    fetchItems();
  }, []);

  const handleAddReward = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:5000/api/shop', {
        name,
        description,
        cost: Number(cost)
      });
      setName('');
      setDescription('');
      setCost('');
      fetchItems();
    } catch (err) {
      console.error('Failed to add reward:', err);
    }
  };

  return (
    <div className="admin-rewards-container">
      <h2>🎁 Admin Reward Manager</h2>

      <form className="reward-form" onSubmit={handleAddReward}>
        <input type="text" value={name} onChange={(e) => setName(e.target.value)} placeholder="Reward name" required />
        <input type="text" value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Description" required />
        <input type="number" value={cost} onChange={(e) => setCost(e.target.value)} placeholder="Cost in coins" required />
        <button type="submit">Add Reward</button>
      </form>

      <div className="reward-list">
        {shopItems.map(item => (
          <div className="reward-card" key={item._id}>
            <h3>{item.name}</h3>
            <p>{item.description}</p>
            <strong>{item.cost} coins</strong>
          </div>
        ))}
      </div>
    </div>
  );
}
