// src/pages/AdminDashboard.jsx
import React from "react";
import { Link } from "react-router-dom";
import styles from "../styles/AdminDashboard.module.css";

export default function AdminDashboard() {
  return (
    <div className={styles.container}>
      <h1 className={styles.title}>Admin Dashboard</h1>

      <div className={styles.cardsGrid}>
        <div className={styles.card}>
          <h2>👨‍🎓 Total Users</h2>
          <p className={styles.stat}>1240</p>
        </div>
        <div className={styles.card}>
          <h2>📚 Active Courses</h2>
          <p className={styles.stat}>18</p>
        </div>
        <div className={styles.card}>
          <h2>🎖️ Certificates Issued</h2>
          <p className={styles.stat}>503</p>
        </div>
        <Link to="/admin/rewards" className={styles.linkCard}>
  <div className={styles.card}>
    <h3>🎁 Reward System</h3>
    <p>Manage shop items and assign coin costs.</p>
  </div>
</Link>

        <Link to="/admin" className={styles.linkCard}>
          <div className={styles.card}>
            <h2>🎥 Start Live Session</h2>
            <p className={styles.stat}>Go to Admin Panel</p>
          </div>
        </Link>
      </div>
    </div>
  );
}
