import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './Tasks.css';

export default function Tasks() {
  const [tasks, setTasks] = useState([]);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [points, setPoints] = useState('');

  useEffect(() => {
    fetchTasks();
  }, []);

  const fetchTasks = async () => {
    try {
      const res = await axios.get('http://localhost:5000/api/tasks');
      setTasks(res.data);
    } catch (err) {
      console.error("Failed to fetch tasks", err);
    }
  };

  const handleAddTask = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:5000/api/tasks', {
        title,
        description,
        points: Number(points),
      });
      setTitle('');
      setDescription('');
      setPoints('');
      fetchTasks();
    } catch (err) {
      console.error("Failed to add task", err);
    }
  };

  return (
    <div className="tasks-container">
      <h2>📋 Task Manager</h2>

      <form className="task-form" onSubmit={handleAddTask}>
        <input type="text" placeholder="Task title" value={title} onChange={(e) => setTitle(e.target.value)} required />
        <input type="text" placeholder="Description" value={description} onChange={(e) => setDescription(e.target.value)} required />
        <input type="number" placeholder="Points" value={points} onChange={(e) => setPoints(e.target.value)} required />
        <button type="submit">Add Task</button>
      </form>

      <div className="task-list">
        {tasks.map(task => (
          <div className="task-card" key={task._id}>
            <h3>{task.title}</h3>
            <p>{task.description}</p>
            <strong>{task.points} points</strong>
          </div>
        ))}
      </div>
    </div>
  );
}
