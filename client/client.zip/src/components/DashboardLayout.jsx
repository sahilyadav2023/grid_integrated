import Topbar from "./Topbar";
import { Outlet } from "react-router-dom";
import styles from "../styles/Dashboard.module.css";

export default function DashboardLayout() {
  return (
    <div className={styles.dashboard}>
      <Topbar />
      <main className={styles.main}>
        <Outlet />
      </main>
    </div>
  );
}
