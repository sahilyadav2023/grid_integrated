import React, { useEffect, useState } from "react";
import io from "socket.io-client";
import styles from "./ChatBox.module.css";

const socket = io("http://localhost:5000");

export default function ChatBox() {
  const [message, setMessage] = useState("");
  const [messages, setMessages] = useState([]);

  const username = localStorage.getItem("username") || "Anonymous";

  useEffect(() => {
    socket.on("chat message", (msg) => {
      console.log("📥 Received on client:", msg);
      setMessages((prev) => [...prev, msg]);
    });

    return () => {
      socket.off("chat message");
    };
  }, []);

  const handleSend = (e) => {
    e.preventDefault();
    if (message.trim()) {
      const msgObj = {
        username,
        text: message,
      };
      console.log("📤 Sending:", msgObj);
      socket.emit("chat message", msgObj);
      setMessage("");
    }
  };

  return (
    <div className={styles.container}>
      <h3 className={styles.heading}>Live Chat</h3>
      <div className={styles.messageBox}>
        {messages.map((msg, index) => (
          <p key={index} className={styles.message}>
            <strong>{msg.username}:</strong> {msg.text}
          </p>
        ))}
      </div>
      <form onSubmit={handleSend} className={styles.form}>
        <input
          type="text"
          className={styles.input}
          placeholder="Type a message..."
          value={message}
          onChange={(e) => setMessage(e.target.value)}
        />
        <button type="submit" className={styles.button}>
          Send
        </button>
      </form>
    </div>
  );
}
