import { Link, useLocation } from "react-router-dom";
import styles from "../styles/Dashboard.module.css";

const links = [
  { to: "/live", label: "Live Session" },
  { to: "/courses", label: "Courses" },
  { to: "/rewards", label: "Rewards" },
  { to: "/profile", label: "Profile" },
];

export default function Topbar() {
  const { pathname } = useLocation();

  return (
    <header className={styles.topbar}>
      <div className={styles.logo}>
        <img src="/assets/grid-logo.png" alt="GRiD Logo" />
        <span className={styles.logoText}>GRiD</span>
      </div>

      <nav className={styles.navLinks}>
        {links.map((link) => (
          <Link
            key={link.to}
            to={link.to}
            className={`${styles.navLink} ${pathname === link.to ? styles.active : ""}`}
          >
            {link.label}
          </Link>
        ))}
      </nav>
    </header>
  );
}
